#' @title AL1 
#' @description L1 soft threshold operator.
#' @param lambda1  Parameter tuning or regularization term parameters.
#' @param etai  Linearized parameters. For PPA, it is a number, and for IPPA, it is a G-dimensional vector.
#' @param  bb  Constant vector.
#' @export
AL1<-function(lambda1,etai,bb){
  beta_k=rep(0, length(bb))
  for (i in 1:length(bb)) {
    beta_k[i]=sign(bb[i])*max(0,abs(bb[i])-lambda1[i]/(etai))
    
  }
  return(beta_k)
}