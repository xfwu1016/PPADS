#' @title Adel
#' @description The solution of the proximal operator in the z-subproblem.
#' @param lambda  Parameter tuning or regularization term parameters.
#' @param lambdav  The first derivative of non convex regularization in local linearization.
#' @param  zz  Constant vector.
#' @param n number of samples.
#' @export
Adel<- function(lambda,lambdav,zz,n=n){
  z_1 = matrix(0,length(zz),1) 
  for (i in 1:length(zz)) {
    z_1[i] =min(max(-n*lambda*lambdav[i], zz[i]),n*lambda*lambdav[i]) }
  return(z_1)
}