#' @title IPPADS
#' @description Improved Proximal Point Algorithm for Dantzig Selector (IPPA for DS).
#' @param pen 'LASSO' or 'SCAD' or 'MCP'.
#' @param lambda  Parameter tuning or regularization term parameters.
#' @param X Matrix of predictors, of dimension (n*p); each row is an observation.
#' @param Xy   Xy represents X multiplied by y (Responses0).
#' @param G The number of blocks in the observation matrix divided by columns.
#' @returns \item{beta}{Regression coefficient.}
#' @returns \item{ite}{number of iterations.}
#' @returns \item{time}{calculation time.}
#' @export
#' @examples
#' #######Example 1(Example of sparse coefficients)
#' n=500
#' p=1000
#' beta=rep(0,p)
#' beta[1:8]=c(3,1.5,10,4,2,5,2.5,4.5)
#' rho <- 0.5
#' R <- matrix(0,p,p)#
#' for(i in 1:p){
#'   for(j in 1:p){
#'     R[i,j] <- rho^abs(i-j)
#'   }
#' }
#' error=rnorm(n,0,1)#rt(n,1.5),rnorm(n,0,1),rcauchy(n,0,1)
#' X <- matrix(rnorm(n*p),n,p) %*% t(chol(R))#chol
#' #X=scale(X,center=FALSE,scale=TRUE)
#' delte=0.1#0.5,1.5
#' y <- X %*% beta + delte*error
#' p = ncol(X)
#' n = nrow(X)
#' 
#' lambda  = 15*10^{-1}*sqrt(log(p)/n) #15*10^{-1}*sqrt(log(p)/n)
#' Xy = t(X)%*%y
#' 
#' ###Lasso
#' Model1_lasso = IPPADS(pen="lasso",lambda,X,Xy ,G=1)#It has insensitivity to partitioning, which #means that no matter how G changes, the solution will not change.
#' Model1_lasso$beta[1:8]
#' Model1_lasso$time
#' #L1-error
#' sum(abs(Model1_lasso$beta - beta))
#' #L2-error
#' sum((Model1_lasso$beta - beta)^2)
#' #Model error
#' sum(as.matrix(Model1_lasso$beta - beta,p,1)*(R%*%as.matrix(Model1_lasso$beta - beta,p,1)))
#' #Number of non-zero coefficients
#' length(which(abs(Model1_lasso$beta)>10^-5))
#' 
#' ###MCP
#' Model1_mcp = IPPADS(pen="mcp",lambda,X,Xy ,G=1)
#' Model1_mcp$beta[1:8]
#' Model1_mcp$time
#' 
#' #L1-error
#' sum(abs(Model1_mcp$beta - beta))
#' #L2-error
#' sum((Model1_mcp$beta - beta)^2)
#' #Model error
#' sum(as.matrix(Model1_mcp$beta - beta,p,1)*(R%*%as.matrix(Model1_mcp$beta - beta,p,1)))
#' #Number of non-zero coefficients
#' length(which(abs(Model1_mcp$beta)>10^-5))
#' 
#' 
#' ###SCAD
#' Model1_scad = IPPADS(pen="scad",lambda,X,Xy ,G=1)
#' Model1_scad$beta[1:8]
#' Model1_scad$time
#' 
#' #L1-error
#' sum(abs(Model1_scad$beta - beta))
#' #L2-error
#' sum((Model1_scad$beta - beta)^2)
#' #Model error
#' sum(as.matrix(Model1_scad$beta - beta,p,1)*(R%*%as.matrix(Model1_scad$beta - beta,p,1)))
#' #Number of non-zero coefficients
#' length(which(abs(Model1_scad$beta)>10^-5))
#' 
#' 
#' #' #######Example 2(Example of Dense coefficients)
#' s=1#s=1,2,3....
#' n=720*s
#' p=2560*s
#' index=1:80
#' ind=sample(index,10)
#' beta=rep(0,p)
#' for (i in 1:10) {
#'   for (j in 1:(32*s)) {
#'     betag=sign(runif(1,-1,1))*(1+ abs(rnorm(32*s,0,1)))
#'   }
#'   beta[((ind[i]-1)*(32*s)+1):((ind[i]-1)*(32*s)+(32*s))]=betag
#' }
#' rho <- 0.5 
#' R <- matrix(0,p,p)#
#' for(i in 1:p){
#'   for(j in 1:p){
#'     R[i,j] <- rho^abs(i-j)
#'   }
#' }
#' 
#' error=rnorm(n,0,1)#rt(n,1.5),rnorm(n,0,1),rcauchy(n,0,1) 
#' X <- matrix(rnorm(n*p),n,p) %*% t(chol(R))#chol
#' X=scale(X,center=FALSE,scale=TRUE)
#' delte=0.5#0.5,1.5
#' y <- X %*% beta + delte*error
#' Xy = t(X)%*%y
#' p = ncol(X)
#' n = nrow(X)
#' 
#' lambda  = 5*10^{-2}*sqrt(log(p)/n)# best 5*10^{-2}*sqrt(log(p)/n)
#' 
#' ###Lasso
#' Model2_lasso = PPADS(pen="lasso",lambda,X,Xy ,G=1)#It has insensitivity to partitioning, which #means that no matter how G changes, the solution will not change.
#' plot(beta)
#' plot(Model2_lasso$beta)
#' #AE
#' sum(abs(Model2_lasso$beta - beta))/p
#' #number of iterations
#' Model2_lasso$ite
#' #computing time
#' Model2_lasso$time
#' 
#' #
#' #FN
#' Nonindex = NULL
#' for (i in 1:10) {
#'   Nonindex =c(Nonindex, ((ind[i]-1)*(32*s)+1):((ind[i]-1)*(32*s)+(32*s))) }
#' 
#' FN_num = 0
#' for (i in Nonindex) {
#'   if(abs(Model2_lasso$beta[i]) >10^-5) {FN_num = FN_num +0 }
#' }
#' FN_num
#' #FP
#' FP_num = 0
#' Oindex = (1:p)[-Nonindex]
#' for (i in Oindex) {
#'   if(abs(Model2_lasso$beta[i]) >10^-4) {FP_num = FP_num +1 }
#' }
#' FP_num
#' 
#' ###MCP
#' Model2_mcp = PPADS(pen="mcp",lambda,X,Xy ,G=1)
#' plot(beta)
#' plot(Model2_mcp$beta)
#' sum(abs(Model2_mcp$beta - beta))/p
#' 
#' 
#' #AE
#' sum(abs(Model2_mcp$beta - beta))/p
#' #number of iterations
#' Model2_mcp$ite
#' #computing time
#' Model2_mcp$time
#' 
#' #
#' #FN
#' Nonindex = NULL
#' for (i in 1:10) {
#'   Nonindex =c(Nonindex, ((ind[i]-1)*(32*s)+1):((ind[i]-1)*(32*s)+(32*s))) }
#' 
#' FN_num = 0
#' for (i in Nonindex) {
#'   if(abs(Model2_mcp$beta[i]) >10^-5) {FN_num = FN_num +0 }
#' }
#' FN_num
#' #FP
#' FP_num = 0
#' Oindex = (1:p)[-Nonindex]
#' for (i in Oindex) {
#'   if(abs(Model2_mcp$beta[i]) >10^-4) {FP_num = FP_num +1 }
#' }
#' FP_num
#' 
#' ###SCAD
#' Model2_scad = PPADS(pen="scad",lambda,X,Xy ,G=1)
#' plot(beta)
#' plot(Model2_scad$beta)
#' sum(abs(Model2_scad$beta - beta))/p
#' 
#' 
#' #AE
#' sum(abs(Model2_scad$beta - beta))/p
#' #number of iterations
#' Model2_scad$ite
#' #computing time
#' Model2_scad$time
#' 
#' 
#' #FN
#' Nonindex = NULL
#' for (i in 1:10) {
#'   Nonindex =c(Nonindex, ((ind[i]-1)*(32*s)+1):((ind[i]-1)*(32*s)+(32*s))) }
#' 
#' FN_num = 0
#' for (i in Nonindex) {
#'   if(abs(Model2_scad$beta[i]) >10^-5) {FN_num = FN_num +0 }
#' }
#' FN_num
#' #FP
#' FP_num = 0
#' Oindex = (1:p)[-Nonindex]
#' for (i in Oindex) {
#'   if(abs(Model2_scad$beta[i]) >10^-4) {FP_num = FP_num +1 }
#' }
#' FP_num

IPPADS<-function(pen,lambda,X,Xy,G){
  p = ncol(X)
  n = nrow(X)
  if(length(lambda)>1){
    lambda = lambda
  }else{lambda = rep(lambda,p)}
  
  begin <- proc.time() #总时间
  if(p>5000){mu = 10^-9}else if(p<2000){ mu = 10^-5}else{mu = 10^-7} 
  group=list()
  ind = rep(1:G, length.out = length((1:p)))
  for (g in 1:G) {
    group[[g]] = (1:p)[ind==(g)]
  }
  
  #创建一个数组
  A_m <- array(0, dim = c(p, p/G,G))
  eta = rep(0,G)
  for (g in 1:G) {
    A_m[,,g] = t(X)%*%X[,group[[g]]]
    eta[g] = mu*pite2(A_m[,,g],x= rep(0.1,length(group[[g]])) ,ite=100)
  }
  ##
  eta = rep(0,G)
  for (g in 1:G) {
    eta[g] = mu*pite2(A_m[,,g],x= rep(0.1,length(group[[g]])) ,ite=100)
  }
  
  ite=500
  beta_la= rep(0.01,p)
  beta_now = beta_la
  z_la = rep(0.01,p)
  d_la = rep(0.01,p)
  rla = 0
  Time1 = rep(0,G)
  for (g in 1:G) {
    begin1 <- proc.time()
    rla = rla + A_m[,,g]%*%beta_la[group[[g]]]
    end1 <- proc.time()
    Time1[G] = (end1 - begin1)[3]
  }
  r_la = (rla - z_la - Xy)
  k=0
  Time2 = matrix(0,G,ite)
  Time3 = matrix(0,G,ite)
  repeat{
    bbb = rep(0,p)
    for (g in 1:G) {
      begin2 <- proc.time()
      bbb[group[[g]]] = beta_la[group[[g]]] + t(A_m[,,g])%*%d_la/eta[g] 
      beta_now[group[[g]]] = AL1(rep(1,p),eta[g],bbb[group[[g]]])  #
      end2 <- proc.time()
      Time2[g,k+1] = (end2 - begin2)[3]
    }
    zzz = z_la - d_la/mu
    z_now = matrix(Adel(lambda[1],lambda,zzz,n),p,1)
    rnow = 0
    for (g in 1:G) {
      begin3 <- proc.time()
      rnow = rnow + A_m[,,g]%*%beta_now[group[[g]]]
      end3 <- proc.time()
      Time3[g,k+1] = (end3 - begin3)[3]
    }
    r_now = (rnow- z_now - Xy)
    d_now = d_la - mu/(G+1)*( 2*r_now - r_la )
    
    Perror=sqrt(sum((beta_now-beta_la)^2))/max(1,sqrt(sum(beta_now^2)))
    if((Perror<10^-3)|(k>ite-2)){break}
    k = k + 1
    beta_la = beta_now
    z_la = z_now
    r_la = r_now
    d_la =d_now
  }
  
  end <- proc.time()
  time_tot = end - begin
  sum2 = 0
  sum3 = 0
  for (i in 1:k) {
    sum2 = sum2 + max(Time2[,i])
    sum3 = sum3 + max(Time3[,i])
  }
  Time = time_tot[3] -  (sum(Time1) + sum(Time2) + sum(Time3)) + (max(Time1) + sum2 + sum3)
  
  ite = k ####增补内容
  if(pen == "mcp"){
    time_la  = Time
    ite_la = k
    beta_lla = beta_now  
    lambda = lambda[1]
    lambdav = mcpder(a=3,beta_lla,lambda1 = lambda)/lambda
    NDS = NCPPAL1(A_m,lambda,lambdav,beta_la,beta_now,z_now,d_now,r_la,G,group,eta,mu)
    beta_now = NDS$nbeta
    Time = time_la + NDS$ntime
    ite = ite_la + NDS$nite
  }
  if(pen == "scad"){
    time_la  = Time
    ite_la = k
    beta_lla = beta_now  
    lambda = lambda[1]
    lambdav = scadder(a=3.7,beta_lla,lambda1 = lambda)/lambda
    NDS = NCPPAL1(A_m,lambda,lambdav,beta_la,beta_now,z_now,d_now,r_la,G,group,eta,mu)
    beta_now = NDS$nbeta
    Time = time_la + NDS$ntime
    ite = ite_la + NDS$nite
    
  }
  
  
  res = list(beta = beta_now,time = Time,ite = k)
  return(res)
}