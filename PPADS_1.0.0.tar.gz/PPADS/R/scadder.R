#' @title scadder
#' @description The first derivative of scad regularization in local linearization.
#' @param a  The constant in the SCAD regularization term has a default value of 3.7.
#' @param beta_lla  Previous solution in LLA algorithm.
#' @param lambda1  Parameter tuning or regularization term parameters.
#' @export
scadder <- function(a=3.7,beta_lla,lambda1){
  Der= rep(0,length(beta_lla))
  for (i in 1:length(beta_lla)) {
    if(abs(beta_lla[i])<=lambda1 ){Der[i] = lambda1}else if(abs(beta_lla[i])> a*lambda1){
      Der[i] = 0}else{Der[i] = (a*lambda1 - abs(beta_lla[i]))/(a-1)}}  
  return(Der)
}