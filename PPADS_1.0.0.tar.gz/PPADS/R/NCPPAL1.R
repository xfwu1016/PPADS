#' @title NCPPAL1
#' @description Function for embedding local linearization to handle non convex regularization terms.
#' @param A_m The segmentation of the observation matrix, where all matrices are concatenated by column to form the entire observation matrix.
#' @param lambda Parameter tuning or regularization term parameters.
#' @param lambdav The first derivative of non convex regularization in local linearization.
#' @param beta_la  The part of solution of the previous iteration of the DS.
#' @param beta_now  The part of solution of the current iteration of the DS.
#' @param z_now  The part of solution of the current iteration of the DS.
#' @param d_now  The part of solution of the current iteration of the DS.
#' @param r_la     The part of solution of the previous iteration of the DS
#' @param G     The number of blocks in the observation matrix divided by columns.
#' @param group  The indicator set in each block of the observation matrix divided by columns.
#' @param eta  Linearized parameters. For PPA, it is a number, and for IPPA, it is a G-dimensional vector.
#' @param mu  The quadratic term augmentation constant.
#' @export
NCPPAL1<-function(A_m,lambda,lambdav,beta_la,beta_now,z_now,d_now,r_la,G,group,eta,mu){
  begin <- proc.time()
  ite=100
  beta_la= beta_la
  beta_now = beta_now
  z_la = z_now
  d_la = d_now
  r_la = r_la
  k=0
  Time2 = matrix(0,G,ite)
  Time3 = matrix(0,G,ite)
  repeat{
    bbb = rep(0,p)
    for (g in 1:G) {
      begin2 <- proc.time()
      bbb[group[[g]]] = beta_la[group[[g]]] + t(A_m[,,g])%*%d_la/eta 
      beta_now[group[[g]]] = AL1(lambdav,eta,bbb[group[[g]]])  #
      end2 <- proc.time()
      Time2[g,k+1] = (end2 - begin2)[3]
    }
    zzz = z_la - d_la/mu
    z_now = matrix(Adel(lambda,lambdav,zzz,n),p,1)
    rnow = 0
    for (g in 1:G) {
      begin3 <- proc.time()
      rnow = rnow + A_m[,,g]%*%beta_now[group[[g]]]
      end3 <- proc.time()
      Time3[g,k+1] = (end3 - begin3)[3]
    }
    r_now = (rnow- z_now - Xy)
    d_now = d_la - mu/2*( 2*r_now - r_la )
    #mu = mu_f(mu,k,eta,k_max,t1,t2)
    Perror=sqrt(sum((beta_now-beta_la)^2))/max(1,sqrt(sum(beta_now^2)))
    if((k>3)&((Perror<0.3*10^-2)|(k>ite-2))){break}
    k = k + 1
    beta_la = beta_now
    z_la = z_now
    r_la = r_now
    d_la =d_now
  }
  
  end <- proc.time()
  time_tot = end - begin
  sum2 = 0
  sum3 = 0
  for (i in 1:k) {
    sum2 = sum2 + max(Time2[,i])
    sum3 = sum3 + max(Time3[,i])
  }
  nite = k
  nTime = time_tot[3] -   (sum(Time2) + sum(Time3)) + (sum2 + sum3)
  nres = list(nbeta = beta_now,ntime = nTime,nite = nite)
  return(nres)
}
