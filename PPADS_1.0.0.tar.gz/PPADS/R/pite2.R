#' @title pite2
#' @description The power method calculates the maximum eigenvalue of a positive definite matrix.
#' @param X  A positive definite matrix.
#' @param x  Non-zero constant vector.  
#' @param ite  Maximum number of iterations.
#' @export
pite2=function(X,x,ite)
{
  x_m=matrix(0,nrow=ncol(X),ncol=ite+1)
  x_m[,1]=x
  k=0
  repeat{
    x_u=t(X)%*%(X%*%x_m[,k+1])
    x_u=x_u/sqrt(sum(x_u^2))
    lam_u= (sum((X%*%x_u)^2))
    k=k+1
    x_m[,k+1]=x_u
    err_a<-max(abs(x_m[,k+1]-x_m[,k]))
    if((err_a<0.001)|(k>ite-1)){break}
  }
  
  return(lam_u)
}